module.exports = {
  LANG_DEFAULT_LOCALE: 'ko',
  LANG_TYPE: {
    KO: 'ko',
    EN: 'en',
    CN: 'cn',
    JP: 'jp',
    SP: 'sp'
  }
}
